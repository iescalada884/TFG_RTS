// From:
// http://www.goodwebpractices.com/roi/track-downloads-in-google-analytics-automatically.html
// http://www.goodwebpractices.com/downloads/gatag.js
// Edited: added a few types,

if (document.getElementsByTagName) {
		// Initialize external link handlers
		var hrefs = document.getElementsByTagName("a");
		for (var l = 0; l < hrefs.length; l++) {
			try {
					//protocol, host, hostname, port, pathname, search, hash
					if (hrefs[l].protocol == "mailto:") {
							gatag_startListening(hrefs[l],"click",gatag_trackMailto);
					} 
					else if (hrefs[l].hostname == location.host) {
							var path = hrefs[l].pathname + hrefs[l].search;
							var isDoc = path.match(/\.(?:doc|eps|jpg|png|gif|bmp|svg|xls|ppt|pdf|xls|csv|zip|tar|gz|bz2|dmg|txt|vsd|vxd|js|css|rar|exe|wma|mov|avi|wmv|mp3|mp4|c|cpp|java|scala|properties)($|\&|\?)/);
							if (isDoc) {
									gatag_startListening(hrefs[l],"click",gatag_trackExternalLinks);
							}
					} 
					else {
							gatag_startListening(hrefs[l],"click",gatag_trackExternalLinks);
					}
			}
			catch(e) {
					continue;
			}
		}
}

function gatag_startListening(obj,evnt,func) {
		if (obj.addEventListener) {
				obj.addEventListener(evnt,func,false);
		} else if (obj.attachEvent) {
				obj.attachEvent("on" + evnt,func);
		}
}

function gatag_trackMailto(evnt) {
		var href = (evnt.srcElement) ? evnt.srcElement.href : this.href;
		var mailto = "/mailto/" + href.substring(7);
		if (typeof(pageTracker) == "object") pageTracker._trackPageview(mailto);
}

function gatag_trackExternalLinks(evnt) {
		var e = (evnt.srcElement) ? evnt.srcElement : this;
		while (e.tagName != "A") {
				e = e.parentNode;
		}
		var lnk = (e.pathname.charAt(0) == "/") ? e.pathname : "/" + e.pathname;
		if (e.search && e.pathname.indexOf(e.search) == -1) lnk += e.search;
		if (e.hostname != location.host) lnk = "/external/" + e.hostname + lnk;
		if (typeof(pageTracker) == "object") pageTracker._trackPageview(lnk); 
}