//-------------------------------------------------------------------
//	backward.cpp
//
//	This demo program must be executed from a text-mode console.
//
//	  compile using:  $ g++ backward.cpp int86.cpp -o backward
//
//	programmer: ALLAN CRUSE
//	written on: 04 SEP 2003
//	revised on: 07 SEP 2005 - replace 'mmap()' with 'init8086()'
//-------------------------------------------------------------------

#include <stdio.h>	// for printf()  
#include <sys/io.h>  	// for iopl()
#include "int86.h"	// for init8086() 

#define TSEQ_PORT   0x03C4	// Index Port for VGA Timer-Sequencer
#define GRFX_PORT   0x03CE	// Index Port for Graphics Controller

unsigned char	*vram = (unsigned char*)0xA0000;
struct vm86plus_struct	vm;

int main( int argc, char **argv )
{
	// initialization
	init8086();	// setup a simulated 8086 environment

	// prologue
	outw( 0x0100, TSEQ_PORT );	// enter synchronous reset
	outw( 0x0402, TSEQ_PORT );	// write only to map 2
	outw( 0x0704, TSEQ_PORT );	// use sequential addressing
	outw( 0x0300, TSEQ_PORT );	// leave synchronous reset
	outw( 0x0204, GRFX_PORT );	// select map 2 for reads
	outw( 0x0005, GRFX_PORT );	// disable odd-even addressing
	outw( 0x0006, GRFX_PORT );	// map starts at 0xA000:0000
	
	// modify the contents of the character-generator ram
	// (256 character-glyphs, each is 32 bytes in length) 
	for (int i = 0; i < 256*32; i++)
		{
		unsigned char	orig, revs = 0;
		orig = vram[ i ];		// fetch the byte
		for (int j = 0; j < 8; j++)  	// rearrange bits
			if ( orig & (1<<j) ) revs |= 1<<(7-j);
		vram[ i ] = revs;		// write new byte
		}

	// epilogue
	outw( 0x0100, TSEQ_PORT );	// enter synchronous reset
	outw( 0x0302, TSEQ_PORT );	// write to maps 0 and 1
	outw( 0x0304, TSEQ_PORT );	// use odd-even addressing
	outw( 0x0300, TSEQ_PORT );	// leave synchronous reset
	outw( 0x0004, GRFX_PORT );	// select map 0 for reads
	outw( 0x1005, GRFX_PORT );	// enable odd-even addressing
	outw( 0x0E06, GRFX_PORT );	// map starts at 0xB800:0000
}
